from flask import Flask, render_template_string, request, jsonify

app = Flask(__name__)

# ═══════════════════════════════════════════════════════════
#  STRICT CINEMA DATABASE & DIRECT LINKS
# ═══════════════════════════════════════════════════════════

CINEMA_LINKS = {
    "PVR Cinemas One Galle Face": "https://lk.bookmyshow.com/sri-lanka/cinemas/pvr-cinema-one-galle-face-mall/POGF",
    "Colombo City Center": "https://lk.bookmyshow.com/sri-lanka/cinemas/scope-cinemas-colombo-city-center/CCCS",
    "Havelock City Mall": "https://lk.bookmyshow.com/sri-lanka/cinemas/scope-cinemas-multiplex-havelock-city-mall/SCMH",
    "Liberty Scope Colombo": "https://lk.bookmyshow.com/sri-lanka/cinemas/liberty-by-scope-cinemas-colombo-screen-1/LCCS",
    "Liberty Scope Kiribathgoda": "https://lk.bookmyshow.com/sri-lanka/cinemas/liberty-scope-cinemas-kiribathgoda/LSSK",
    "Sky Lite 3D Matara": "https://lk.bookmyshow.com/buytickets/sky-lite-3d-cinema-matara/cinema-snlk-SKKS-MT/20260301",
    "Max Lite 3D Moratuwa": "https://lk.bookmyshow.com/buytickets/maxx-lite-3d-cinema-moratuwa/cinema-snlk-MAXC-MT/20260301",
    "Amity Lite 3D Maharagama": "https://lk.bookmyshow.com/buytickets/amity-lite-3d-cinema-maharagama/cinema-snlk-AAMM-MT/20260301",
    "Aqua Lite Negambo": "https://lk.bookmyshow.com/sri-lanka/cinemas/aqua-lite-3d-cinema-negombo/ALCN",
    "VoxX Lite Avissawella": "https://lk.bookmyshow.com/buytickets/voxx-lite-3d-cinema-avissawella/cinema-snlk-VOXX-MT/20260301",
    "City Lite Mt.Lavinia": "https://lk.bookmyshow.com/sri-lanka/cinemas/city-lite-cinema-mt-lavinia/CLCL",
    "Nikado by Lite Kadawatha": "https://lk.bookmyshow.com/sri-lanka/cinemas/nikado-cinema-kadawatha/NNCC",
    "Lite Cinema Homagama": "https://lk.bookmyshow.com/sri-lanka/cinemas/lite-cinema-lekha-homagama/LLLM",
    "Lite Cinema Kaduwela": "https://lk.bookmyshow.com/sri-lanka/cinemas/vijayanthi-by-lite-cinemas-kaduwela/VLCK",
    "Misty Lite 3D Nawalapitiya": "https://lk.bookmyshow.com/sri-lanka/cinemas/misty-lite-3d-cinema-nawalapitiya/MLCN",
    "Neela by Lite Dankotuwa": "https://lk.bookmyshow.com/sri-lanka/cinemas/neela-by-lite-cinema-dankotuwa/NLCD",
    "Sarasavi by Lite Alawwa": "https://lk.bookmyshow.com/sri-lanka/cinemas/sarasavi-cinema-alawwa/SCCA",
    "Priska Lite 3D Kalutara": "https://lk.bookmyshow.com/buytickets/priska-lite-3d-cinema-kalutara/cinema-snlk-PLCK-MT/20260301",
    "Savoy 3D Wellawatte": "https://lk.bookmyshow.com/sri-lanka/cinemas/savoy-3d-dolby-atmos-wellawatta/SCWT",
    "Savoy 2 Wellawatte": "https://lk.bookmyshow.com/sri-lanka/cinemas/savoy-3d-dolby-atmos-wellawatta/SCWT",
    "Savoy premier Roxy Wellawatta": "https://lk.bookmyshow.com/sri-lanka/cinemas/savoy-premiere-roxy-cinema-wellawatte/SCPW",
    "Savoye Premier Rajagiriya": "https://lk.bookmyshow.com/sri-lanka/cinemas/savoy-premier-rajagiriya/SPRG",
    "Savoye Metro Maharagama": "https://lk.bookmyshow.com/sri-lanka/cinemas/savoy-metro-maharagama/SCMA",
    "Savoye Metro Gampaha": "https://lk.bookmyshow.com/sri-lanka/cinemas/savoy-metro-gampaha/SMGS",
    "S.K Cinema Matara": "https://lk.bookmyshow.com/sri-lanka/cinemas/sk-cinema-matara/SKCM",
    "Sinexpo 3D Kurunagala": "https://lk.bookmyshow.com/buytickets/sinexpo-3d-kurunegala/cinema-snlk-SNKG-MT/20260301",
    "Will Max Anuradhapura": "https://lk.bookmyshow.com/buytickets/willmax-anuradhapura/cinema-snlk-WCAP-MT/20260301",
    "Cinemax 3D Ja ela": "https://lk.bookmyshow.com/sri-lanka/cinemas/cinemax-3d-jaela/CCJL",
    "Concord Dehiwala": "https://lk.bookmyshow.com/sri-lanka/cinemas/concord-dehiwala/CCDL",
    "Regal Ambalangoda": "https://lk.bookmyshow.com/buytickets/regal-ambabalangoda/cinema-snlk-RCAG-MT/20260301",
    "Jothi Rathnapura": "https://lk.bookmyshow.com/sri-lanka/cinemas/jothi-rathnapura/JPRP",
    "Samantha 2D Dematagoda": "https://lk.bookmyshow.com/sri-lanka/cinemas/samantha-cinema-dematagoda/SCDG",
    "Ram Cinema Wattala": "https://lk.bookmyshow.com/buytickets/ram-cinemas-wattala/cinema-snlk-RCCW-MT/20260301",
    "Ruhunu Cinema Tangalle": "https://cinematreasures.org/theaters/44360",
    "CK Cinema Kirindiwela": "https://lk.bookmyshow.com/sri-lanka/cinemas/ck-cinema-kirindiwela/CKCK",
    "Imperial 3D Kurunagala": "https://lk.bookmyshow.com/buytickets/imperial-3d-cinema-kurunegala/cinema-snlk-IMDK-MT/20260301",
    "Sarasavi Cinema Alawwa": "https://lk.bookmyshow.com/sri-lanka/cinemas/sarasavi-cinema-alawwa/SCCA",
    "Ruoo Katunayake": "https://lk.bookmyshow.com/sri-lanka/cinemas/ruoo-cinema-katunayake/RCNM",
    "New Janaki Mathugama": "https://lk.bookmyshow.com/sri-lanka/cinemas/new-janaki-cinema-mathugama/NJCM",
    "SAS Cineplex Trincomalee": "https://lk.bookmyshow.com/buytickets/sas-cineplex-trincomale/cinema-snlk-SASC-MT/20260301",
    "Rex Theater Badulla": "https://lk.bookmyshow.com/buytickets/rex-theater-badulla/cinema-snlk-RXXE-MT/20260301",
    "Nikado Cinema Kadawatha": "https://lk.bookmyshow.com/buytickets/nikado-cinema-kadawatha/cinema-snlk-NNCC-MT/20260301",
    "Shamroack Cinema Wennappuwa": "https://lk.bookmyshow.com/buytickets/shamrock-cinema-wennappuwa/cinema-snlk-SSCO-MT/20260301",
    "Vijaya Cinema Minuwangoda": "https://lk.bookmyshow.com/buytickets/vijaya-cinema-minuwangoda/cinema-snlk-VCCM-MT/20260301",
    "KCC Multiplex Kandy City Center": "https://kccmultiplex.lk/buy-tickets/",
    "JP Complex Kandy": "https://www.jpcineplex.com/",
    "Ananda Cinema Gampola": "https://dialus.lk/listing/Kandy/Gampola/ananda-cinema/4102"
}

CITY_DATA = {
    "Anuradhapura": ["Will Max Anuradhapura"],
    "Badulla": ["Rex Theater Badulla"],
    "Colombo": ["PVR Cinemas One Galle Face", "Colombo City Center", "Havelock City Mall", "Liberty Scope Colombo", "Liberty Scope Kiribathgoda", "Max Lite 3D Moratuwa", "Amity Lite 3D Maharagama", "VoxX Lite Avissawella", "City Lite Mt.Lavinia", "Lite Cinema Homagama", "Lite Cinema Kaduwela", "Savoy 3D Wellawatte", "Savoy 2 Wellawatte", "Savoy premier Roxy Wellawatta", "Savoye Premier Rajagiriya", "Savoye Metro Maharagama", "Concord Dehiwala", "Samantha 2D Dematagoda"],
    "Gampaha": ["Aqua Lite Negambo", "Nikado by Lite Kadawatha", "Savoye Metro Gampaha", "Cinemax 3D Ja ela", "Ram Cinema Wattala", "CK Cinema Kirindiwela", "Ruoo Katunayake", "Nikado Cinema Kadawatha", "Shamroack Cinema Wennappuwa", "Vijaya Cinema Minuwangoda"],
    "Galle": ["Regal Ambalangoda"],
    "Hambantota": ["Ruhunu Cinema Tangalle"],
    "Kalutara": ["Priska Lite 3D Kalutara", "New Janaki Mathugama"],
    "Kandy": ["KCC Multiplex Kandy City Center", "JP Complex Kandy", "Ananda Cinema Gampola", "Misty Lite 3D Nawalapitiya"],
    "Kurunegala": ["Imperial 3D Kurunagala", "Sarasavi Cinema Alawwa", "Sinexpo 3D Kurunagala"],
    "Matara": ["Sky Lite 3D Matara", "S.K Cinema Matara"],
    "Puttalam": ["Neela by Lite Dankotuwa"],
    "Rathnapura": ["Jothi Rathnapura"],
    "Trincomalee": ["SAS Cineplex Trincomalee"]
}

CHAINS = {
    "PVR Cinemas": ["PVR Cinemas One Galle Face"],
    "Scope Cinemas": ["Colombo City Center", "Havelock City Mall", "Liberty Scope Colombo", "Liberty Scope Kiribathgoda"],
    "Lite Cinemas": ["Sky Lite 3D Matara", "Max Lite 3D Moratuwa", "Amity Lite 3D Maharagama", "Aqua Lite Negambo", "VoxX Lite Avissawella", "City Lite Mt.Lavinia", "Nikado by Lite Kadawatha", "Lite Cinema Homagama", "Lite Cinema Kaduwela", "Misty Lite 3D Nawalapitiya", "Neela by Lite Dankotuwa", "Sarasavi by Lite Alawwa", "Priska Lite 3D Kalutara"],
    "EAP Cinemas": ["Savoy 3D Wellawatte", "Savoy 2 Wellawatte", "Savoy premier Roxy Wellawatta", "Savoye Premier Rajagiriya", "Savoye Metro Maharagama", "Savoye Metro Gampaha", "S.K Cinema Matara", "Sinexpo 3D Kurunagala", "Will Max Anuradhapura", "Cinemax 3D Ja ela", "Concord Dehiwala", "Regal Ambalangoda", "Jothi Rathnapura", "Samantha 2D Dematagoda"],
    "Independent": ["Ram Cinema Wattala", "Ruhunu Cinema Tangalle", "CK Cinema Kirindiwela", "Imperial 3D Kurunagala", "Sarasavi Cinema Alawwa", "Ruoo Katunayake", "New Janaki Mathugama", "SAS Cineplex Trincomalee", "Rex Theater Badulla", "Nikado Cinema Kadawatha", "Shamroack Cinema Wennappuwa", "Vijaya Cinema Minuwangoda", "KCC Multiplex Kandy City Center", "JP Complex Kandy", "Ananda Cinema Gampola"]
}

MOVIES = [
    {"name": "Father", "trailer": "https://www.youtube.com/watch?v=wZq_svKB0KQ"},
    {"name": "Dharmayuddhaya 2", "trailer": "https://www.youtube.com/watch?v=HtQP3QItZGY"},
    {"name": "Malaki Duwe Numba", "trailer": "https://www.youtube.com/watch?v=WU799Q8o5br8"},
    {"name": "The Wife", "trailer": "https://www.youtube.com/watch?v=m-7DB0kohlg"}
]

INDEX_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CineLanka Premium</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root { --ink: #0d0d12; --gold: #d4a840; --card: #16161f; --txt: #e8e8f0; --dim: #7a7a96; --hover: #222; }
        body { font-family: 'DM Sans', sans-serif; background: var(--ink); color: var(--txt); margin: 0; }
        .landing { display: flex; align-items: center; justify-content: space-between; min-height: 100vh; padding: 0 8%; }
        .hero-title h1 { font-size: 4.5rem; margin: 0; line-height: 1.1; font-weight: 500; }
        .hero-title em { color: var(--gold); font-style: normal; }
        .input-card { background: var(--card); width: 440px; padding: 3rem 2.5rem; border-radius: 32px; border: 1px solid rgba(255,255,255,0.05); }
        .field { margin-bottom: 1.5rem; }
        .field-lbl { font-size: 0.7rem; color: var(--dim); text-transform: uppercase; margin-bottom: 0.8rem; display: block; font-weight: 700; }
        select { width: 100%; background: #000; border: 1px solid #222; border-radius: 12px; padding: 1.1rem; color: #fff; font-size: 1rem; outline: none; appearance: none; cursor: pointer; }
        .date-wrapper { width: 100%; background: #000; border: 1px solid #222; border-radius: 12px; position: relative; }
        input[type="date"] { width: 100%; padding: 1.1rem; color: #fff; background: transparent; border: none; font-size: 1rem; outline: none; box-sizing: border-box; }
        .calendar-icon { position: absolute; right: 15px; top: 50%; transform: translateY(-50%); color: var(--gold); pointer-events: none; }
        .btn-search { width: 100%; background: var(--gold); color: #000; border: none; padding: 1.2rem; border-radius: 12px; font-weight: 700; cursor: pointer; font-size: 1rem; margin-top: 10px; }
        #category-view, #hall-view { display: none; padding: 60px 8%; }
        .nav-bar { display: flex; gap: 15px; margin-bottom: 40px; }
        .btn-home { background: var(--gold); color: #000; padding: 12px 25px; border-radius: 10px; font-weight: bold; border: none; cursor: pointer; text-transform: uppercase; }
        .cat-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 20px; }
        .cat-item { background: var(--card); padding: 50px 20px; border-radius: 24px; text-align: center; border: 1px solid rgba(255,255,255,0.05); cursor: pointer; transition: 0.3s; }
        .cat-item:hover { border-color: var(--gold); transform: translateY(-5px); }
        .hall-item { background: var(--card); padding: 35px; border-radius: 24px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; border: 1px solid rgba(255,255,255,0.05); }
        .btn-group { display: flex; gap: 12px; }
        .action-btn { text-decoration: none; padding: 14px 22px; border-radius: 12px; font-size: 0.75rem; font-weight: bold; border: 1px solid var(--gold); color: var(--gold); text-transform: uppercase; }
        .action-btn.primary { background: var(--gold); color: #000; }
    </style>
</head>
<body>
    <div id="landing-page" class="landing">
        <div class="hero-title">
            <p style="color: var(--gold); letter-spacing: 2px;">• CINELANKA PREMIUM</p>
            <h1>Find Your<br><em>Perfect Cinema</em></h1>
        </div>
        <div class="input-card">
            <h2 style="margin: 0 0 2rem;">Enter Details</h2>
            <div class="field">
                <label class="field-lbl">Select Movie</label>
                <select id="movie-sel">
                    {% for m in movies %}<option value="{{ m.trailer }}">{{ m.name }}</option>{% endfor %}
                </select>
            </div>
            <div class="field">
                <label class="field-lbl">Main City</label>
                <select id="city-sel">
                    {% for city in cities %}<option value="{{ city }}">{{ city }}</option>{% endfor %}
                </select>
            </div>
            <div class="field">
                <label class="field-lbl">Show Date</label>
                <div class="date-wrapper">
                    <input type="date" id="date-input" value="2026-03-01">
                    <span class="calendar-icon">📅</span>
                </div>
            </div>
            <button class="btn-search" onclick="handleSearch()">SEARCH CINEMAS →</button>
        </div>
    </div>

    <div id="category-view">
        <div class="nav-bar"><button class="btn-home" onclick="goHome()">Back to Home</button></div>
        <h1 id="cat-title" style="font-size: 3rem; margin-bottom: 10px;"></h1>
        <p id="cat-subtitle" style="color: var(--gold); font-weight: 500; font-size: 1.2rem; margin-bottom: 50px;"></p>
        <div id="cat-grid" class="cat-grid"></div>
    </div>

    <div id="hall-view">
        <div class="nav-bar">
            <button class="btn-home" onclick="backToCats()" style="background:#222; color:#fff;">← Back</button>
            <button class="btn-home" onclick="goHome()">Home</button>
        </div>
        <h1 id="hall-title" style="color: var(--gold); margin-bottom: 40px;"></h1>
        <div id="hall-list"></div>
    </div>

    <script>
        let selCity = "", selDate = "", selDateLabel = "", selMovieName = "", selTrailer = "";
        const CITY_MAP = {{ city_data|tojson }};
        const CHAIN_MAP = {{ chains|tojson }};
        const LINKS_DB = {{ links|tojson }};

        function handleSearch() {
            const dateVal = document.getElementById('date-input').value;
            const today = new Date("2026-03-01");
            const target = new Date(dateVal);
            const diff = Math.ceil((target - today) / (1000 * 60 * 60 * 24));

            if (diff < 0 || diff > 3) {
                alert("Date not available. Results only available for 4 days from today.");
                return;
            }

            selDate = dateVal.replace(/-/g, ""); 
            selDateLabel = target.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
            selCity = document.getElementById('city-sel').value;
            selMovieName = document.getElementById('movie-sel').options[document.getElementById('movie-sel').selectedIndex].text;
            selTrailer = document.getElementById('movie-sel').value;

            document.getElementById('cat-title').innerText = `Cinemas in ${selCity}`;
            document.getElementById('cat-subtitle').innerText = selDateLabel;
            renderChains();
        }

        function renderChains() {
            const cityHalls = CITY_MAP[selCity] || [];
            const filteredChains = Object.keys(CHAIN_MAP).filter(chain => 
                CHAIN_MAP[chain].some(hall => cityHalls.includes(hall))
            );
            document.getElementById('cat-grid').innerHTML = filteredChains.map(name => `
                <div class="cat-item" onclick="loadHalls('${name}')">
                    <h2 style="color:var(--gold); margin:0;">${name}</h2>
                    <p style="font-size:0.8rem; color:var(--dim); margin-top:10px;">• LIVE</p>
                </div>
            `).join('');
            document.getElementById('landing-page').style.display = 'none';
            document.getElementById('category-view').style.display = 'block';
        }

        function loadHalls(chain) {
            const cityHalls = CITY_MAP[selCity] || [];
            const hallsInChain = CHAIN_MAP[chain].filter(h => cityHalls.includes(h));
            document.getElementById('hall-title').innerText = `${chain} - ${selCity}`;
            document.getElementById('hall-list').innerHTML = hallsInChain.map(name => {
                let baseLink = LINKS_DB[name] || "#";
                let finalLink = baseLink;

                // Handle date replacement for BookMyShow specific links
                if (finalLink.includes("bookmyshow.com")) {
                    if (finalLink.includes("20260301")) {
                        finalLink = finalLink.replace("20260301", selDate);
                    } else if (finalLink.includes("/buytickets/")) {
                        // For generic BMS buy ticket links
                        finalLink = `https://lk.bookmyshow.com/buytickets/${selDate}`;
                    } else {
                        // Append date to cinema profile links
                        finalLink = finalLink.endsWith('/') ? finalLink + selDate : finalLink + '/' + selDate;
                    }
                }

                return `
                <div class="hall-item">
                    <div>
                        <h2 style="margin:0; font-size: 1.4rem;">${name}</h2>
                        <p style="color:var(--dim); font-size:0.9rem; margin-top:8px;">${selDateLabel} • ${chain} Network</p>
                    </div>
                    <div class="btn-group">
                        <a href="${selTrailer}" target="_blank" class="action-btn">TRAILER</a>
                        <a href="https://www.google.com/maps/search/${encodeURIComponent(name + ' ' + selCity)}" target="_blank" class="action-btn">LOCATION</a>
                        <a href="${finalLink}" target="_blank" class="action-btn primary">BUY TICKETS →</a>
                    </div>
                </div>`;
            }).join('');
            document.getElementById('category-view').style.display = 'none';
            document.getElementById('hall-view').style.display = 'block';
        }

        function goHome() { location.reload(); }
        function backToCats() {
            document.getElementById('hall-view').style.display = 'none';
            document.getElementById('category-view').style.display = 'block';
        }
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(INDEX_HTML, movies=MOVIES, cities=sorted(CITY_DATA.keys()), city_data=CITY_DATA, chains=CHAINS, links=CINEMA_LINKS)

if __name__ == '__main__':
    app.run(debug=True)