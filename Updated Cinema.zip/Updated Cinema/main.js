/* ══════════════════════════════════════════════════
   CINELANKA  –  main.js
   ══════════════════════════════════════════════════ */

// ── State ──────────────────────────────────────────
let currentCity = '';
let currentCategory = '';

// ── Category color map ─────────────────────────────
const CAT_COLORS = {
  pvr:         '#7c3aed',
  scoop:       '#0ea5e9',
  lite:        '#22c55e',
  eap:         '#e83a3a',
  independent: '#f97316',
};

const CAT_LABELS = {
  pvr:         'PVR Cinemas',
  scoop:       'Scoop Cinemas',
  lite:        'Lite Cinemas',
  eap:         'EAP Cinemas',
  independent: 'Independent',
};

// ── Init ───────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Set today's date as default
  const dateInput = document.getElementById('date-input');
  const today = new Date().toISOString().split('T')[0];
  dateInput.value = today;

  // Close panel on Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closePanel();
  });
});

// ── Search ─────────────────────────────────────────
function doSearch() {
  const citySelect = document.getElementById('city-select');
  const dateInput  = document.getElementById('date-input');

  currentCity = citySelect.value;
  const dateValue = dateInput.value;

  // Update results header
  document.getElementById('results-city-name').textContent =
    currentCity || 'All Sri Lanka';

  if (dateValue) {
    const d = new Date(dateValue);
    document.getElementById('results-date-display').textContent =
      d.toLocaleDateString('en-US', { weekday:'long', year:'numeric', month:'long', day:'numeric' });
  }

  // Show/hide sections
  document.getElementById('hero-section').style.display = 'none';
  document.getElementById('results-section').style.display = 'block';
  document.getElementById('app-footer').style.display = 'block';

  // If city selected, load city cinemas
  if (currentCity) {
    loadCityCinemas(currentCity);
  } else {
    document.getElementById('city-section').style.display = 'none';
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ── Go Back ────────────────────────────────────────
function goBack() {
  document.getElementById('results-section').style.display = 'none';
  document.getElementById('app-footer').style.display = 'none';
  document.getElementById('hero-section').style.display = 'flex';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ── Load City Cinemas (via API) ─────────────────────
async function loadCityCinemas(city) {
  const section = document.getElementById('city-section');
  const grid    = document.getElementById('city-cinema-grid');
  const title   = document.getElementById('city-section-title');

  title.textContent = `All Cinemas in ${city}`;
  section.style.display = 'block';
  grid.innerHTML = `<div class="panel-loading"><div class="spinner"></div> Loading cinemas…</div>`;

  try {
    const res  = await fetch(`/api/cities/${encodeURIComponent(city)}`);
    const data = await res.json();

    if (!data.length) {
      grid.innerHTML = `<div class="empty-state"><div class="empty-icon">🎞️</div><p class="empty-text">No cinemas found in ${city}.</p></div>`;
      return;
    }

    grid.innerHTML = data.map(c => renderCinemaCard(c, c.category)).join('');
  } catch (err) {
    grid.innerHTML = `<div class="empty-state"><div class="empty-icon">⚠️</div><p class="empty-text">Failed to load cinemas. Make sure the Flask server is running.</p></div>`;
    console.error(err);
  }
}

// ── Open Panel ─────────────────────────────────────
async function openPanel(category) {
  currentCategory = category;

  // Set panel header
  const color = CAT_COLORS[category] || '#fff';
  document.getElementById('panel-dot').style.background = color;
  document.getElementById('panel-dot').style.boxShadow = `0 0 10px ${color}`;
  document.getElementById('panel-title').textContent = CAT_LABELS[category] || category;

  // Show overlay + panel
  document.getElementById('panel-overlay').classList.add('open');
  document.getElementById('cinema-panel').classList.add('open');
  document.body.style.overflow = 'hidden';

  // Show loading
  const body = document.getElementById('panel-body');
  body.innerHTML = `<div class="panel-loading"><div class="spinner"></div> Loading cinemas…</div>`;

  try {
    const cityParam = currentCity ? `?city=${encodeURIComponent(currentCity)}` : '';
    const res  = await fetch(`/api/cinemas/${category}${cityParam}`);
    const data = await res.json();

    // Update subtitle
    document.getElementById('panel-subtitle').textContent =
      data.length
        ? `${data.length} location${data.length !== 1 ? 's' : ''}${currentCity ? ` in ${currentCity}` : ''}`
        : 'No locations found';

    if (!data.length) {
      body.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🎞️</div>
          <p class="empty-text">No ${CAT_LABELS[category]} cinemas found${currentCity ? ` in ${currentCity}` : ''}.</p>
        </div>`;
      return;
    }

    body.innerHTML = data.map(c => renderPanelItem(c)).join('');
  } catch (err) {
    body.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">⚠️</div>
        <p class="empty-text">Failed to load data. Is the Flask server running on port 5000?</p>
      </div>`;
    console.error(err);
  }
}

// ── Close Panel ─────────────────────────────────────
function closePanel() {
  document.getElementById('panel-overlay').classList.remove('open');
  document.getElementById('cinema-panel').classList.remove('open');
  document.body.style.overflow = '';
}

// ── Render Helpers ──────────────────────────────────

function renderPanelItem(c) {
  return `
    <div class="panel-cinema-item">
      <div class="panel-cinema-name">${c.name}</div>
      <div class="panel-cinema-loc">📍 ${c.location}</div>
      <div class="panel-cinema-desc">${c.desc}</div>
      <div class="panel-cinema-btns">
        <a class="btn-loc"    href="${c.map}"    target="_blank" rel="noopener">📍 Location</a>
        <a class="btn-ticket" href="${c.ticket}" target="_blank" rel="noopener">🎟 Book Tickets</a>
      </div>
    </div>`;
}

function renderCinemaCard(c, category) {
  const badgeClass = `badge-${category}`;
  const catLabel   = CAT_LABELS[category] || category;
  return `
    <div class="cinema-card">
      <div class="cinema-card-header">
        <div class="cinema-card-name">${c.name}</div>
        <span class="cinema-cat-badge ${badgeClass}">${catLabel}</span>
      </div>
      <div class="cinema-card-loc">📍 ${c.location}</div>
      <div class="cinema-card-desc">${c.desc}</div>
      <div class="cinema-card-btns">
        <a class="btn-loc"    href="${c.map}"    target="_blank" rel="noopener">📍 Location</a>
        <a class="btn-ticket" href="${c.ticket}" target="_blank" rel="noopener">🎟 Book Tickets</a>
      </div>
    </div>`;
}

// ── Allow Enter key to search ──────────────────────
document.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    const hero = document.getElementById('hero-section');
    if (hero.style.display !== 'none') doSearch();
  }
});
