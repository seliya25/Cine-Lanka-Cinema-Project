from flask import Flask, render_template_string
import json

app = Flask(__name__)

# --- CONFIGURATION DATA ---
MOVIES = [
    {"name": "Father", "img": "Father.jpg", "trailer": "https://www.youtube.com/watch?v=IhgcUArO3Uo"},
    {"name": "Dharmayuddaya 02", "img": "dharmayuddaya.jpg", "trailer": "https://www.youtube.com/watch?v=HtQP3QItZGY&t=9s"},
    {"name": "Malaki Duwe Numba", "img": "Malaki.jpg", "trailer": "https://www.youtube.com/watch?v=WU79Q8o5br8&t=25s"},
    {"name": "Karuppu", "img": "Karuppu.jpg", "trailer": "https://www.youtube.com/watch?v=Llss1aRo8tw"},
    {"name": "The Bride", "img": "The bride.avif", "trailer": "https://www.youtube.com/watch?v=IhgcUArO3Uo"},
    {"name": "Zootopia 2", "img": "zootopia.jpg", "trailer": "https://www.youtube.com/watch?v=BjkIOU5PhyQ"},
    {"name": "Avatar: Fire and Ash", "img": "avatar.jpg", "trailer": "https://www.youtube.com/watch?v=nb_fFj_0rq8"},
    {"name": "The SpongeBob Movie", "img": "spongebob.jpg", "trailer": "https://www.youtube.com/results?search_query=the+spongebob+movie+search+for+squarepants+trailer"}
]

CITY_DATA = {
    "Colombo": ["PVR Cinemas One Galle Face", "Colombo City Center", "Havelock City Mall", "Liberty Scoop Colombo", "Liberty Scoop Kiribathgoda", "Max Lite 3D Moratuwa", "Amity Lite 3D Maharagama", "VoxX Lite Avissawella", "City Lite Mt.Lavinia", "Lite Cinema Homagama", "Lite Cinema Kaduwela", "Savoy 3D Wellawatte", "Savoy 2 Wellawatte", "Savoy premier Roxy Wellawatta", "Savoye Premier Rajagiriya", "Savoye Metro Maharagama", "Concord Dehiwala", "Samantha 2D Dematagoda"],
    "Gampaha": ["Aqua Lite Negambo", "Nikado by Lite Kadawatha", "Savoye Metro Gampaha", "Cinemax 3D Ja ela", "Ram Cinema Wattala", "CK Cinema Kirindiwela", "Ruoo Katunayake", "Nikado Cinema Kadawatha", "Shamroack Cinema Wennappuwa", "Vijaya Cinema Minuwangoda"],
    "Kandy": ["KCC Multiplex Kandy City Center", "JP Complex Kandy", "Ananda Cinema Gampola", "Misty Lite 3D Nawalapitiya"],
    "Matara": ["Sky Lite 3D Matara", "S.K Cinema Matara"],
    "Kalutara": ["Priska Lite 3D Kalutara", "New Janaki Mathugama"],
    "Galle": ["Regal Ambalangoda"],
    "Hambantota": ["Ruhunu Cinema Tangalle"],
    "Kurunegala": ["Imperial 3D Kurunagala", "Sarasavi Cinema Alawwa", "Sinexpo 3D Kurunagala"],
    "Puttalam": ["Neela by Lite Dankotuwa"],
    "Anuradhapura": ["Will Max Anuradhapura"],
    "Trincomalee": ["SAS Cineplex Trincomalee"],
    "Badulla": ["Rex Theater Badulla"],
    "Rathnapura": ["Jothi Rathnapura"]
}

CHAINS = {
    "PVR": ["PVR Cinemas One Galle Face"],
    "Scope": ["Colombo City Center", "Havelock City Mall", "Liberty Scoop Colombo", "Liberty Scoop Kiribathgoda"],
    "Lite": ["Sky Lite 3D Matara", "Max Lite 3D Moratuwa", "Amity Lite 3D Maharagama", "Aqua Lite Negambo", "VoxX Lite Avissawella", "City Lite Mt.Lavinia", "Nikado by Lite Kadawatha", "Lite Cinema Homagama", "Lite Cinema Kaduwela", "Misty Lite 3D Nawalapitiya", "Neela by Lite Dankotuwa", "Sarasavi by Lite Alawwa", "Priska Lite 3D Kalutara"],
    "EAP": ["Savoy 3D Wellawatte", "Savoy 2 Wellawatte", "Savoy premier Roxy Wellawatta", "Savoye Premier Rajagiriya", "Savoye Metro Maharagama", "Savoye Metro Gampaha", "S.K Cinema Matara", "Sinexpo 3D Kurunagala", "Will Max Anuradhapura", "Cinemax 3D Ja ela", "Concord Dehiwala", "Regal Ambalangoda", "Jothi Rathnapura", "Samantha 2D Dematagoda"],
    "Independent": ["Ram Cinema Wattala", "Ruhunu Cinema Tangalle", "CK Cinema Kirindiwela", "Imperial 3D Kurunagala", "Sarasavi Cinema Alawwa", "Ruoo Katunayake", "New Janaki Mathugama", "SAS Cineplex Trincomalee", "Rex Theater Badulla", "Nikado Cinema Kadawatha", "Shamroack Cinema Wennappuwa", "Vijaya Cinema Minuwangoda", "KCC Multiplex Kandy City Center", "JP Complex Kandy", "Ananda Cinema Gampola"]
}

# Add URL data similarly...
URLS = {
    "PVR Cinemas One Galle Face": "https://lk.bookmyshow.com/sri-lanka/cinemas/pvr-cinema-one-galle-face-mall/POGF",
    "Colombo City Center": "https://lk.bookmyshow.com/sri-lanka/cinemas/scope-cinemas-colombo-city-center/CCCS",
    # ... other URLs ...
}

HTML_PAGE = """
<!DOCTYPE html>
<html>
<head>
    <title>CineLanka - Professional Booking</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    <style>
        :root { --gold: #D4A840; --gold-l: #E5C270; --bg: #0A0A0B; --glass: rgba(255,255,255,0.03); }
        body { background: var(--bg); color: white; font-family: 'Outfit', sans-serif; margin: 0; overflow-x: hidden; }
        
        .hero { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 2rem; }
        .card { background: var(--glass); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.1); padding: 3rem; border-radius: 30px; width: 100%; max-width: 500px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.5); }
        
        .field { margin-bottom: 1.5rem; position: relative; }
        label { display: block; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.1em; color: var(--gold); margin-bottom: 0.5rem; font-weight: 600; }
        select, input { width: 100%; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); padding: 1rem; border-radius: 12px; color: white; font-size: 1rem; cursor: pointer; }
        
        .cat-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 10px; margin-top: 2rem; }
        .cat-btn { background: var(--glass); border: 1px solid rgba(255,255,255,0.1); padding: 15px 5px; border-radius: 15px; text-align: center; cursor: pointer; transition: 0.3s; font-size: 0.7rem; font-weight: 800; color: #aaa; }
        .cat-btn:hover { border-color: var(--gold); color: var(--gold); transform: translateY(-3px); }

        .btn-search { width: 100%; background: var(--gold); color: black; border: none; padding: 1.2rem; border-radius: 15px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.1em; cursor: pointer; margin-top: 1rem; }
        
        #results-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.9); display: none; padding: 2rem; z-index: 100; overflow-y: auto; }
        .cinema-card { background: var(--glass); border: 1px solid rgba(255,255,255,0.1); padding: 20px; border-radius: 20px; margin-bottom: 15px; }
        .btn-grp { display: flex; gap: 10px; margin-top: 15px; }
        .btn-s { flex: 1; padding: 10px; border-radius: 10px; text-decoration: none; text-align: center; font-size: 0.8rem; font-weight: 600; }
        .b-tra { background: #ff0000; color: white; }
        .b-loc { background: #4285F4; color: white; }
        .b-book { background: var(--gold); color: black; }
    </style>
</head>
<body>
    <div class="hero">
        <div class="card">
            <h1 style="margin-top:0">CineLanka</h1>
            <div class="field">
                <label>Movie</label>
                <select id="m">
                    {% for mv in movies %}
                    <option value="{{ mv.trailer }}">{{ mv.name }}</option>
                    {% endfor %}
                </select>
            </div>
            <div class="field">
                <label>City</label>
                <select id="c">
                    {% for city in cities %}
                    <option>{{ city }}</option>
                    {% endfor %}
                </select>
            </div>
            <div class="field">
                <label>Date 📅</label>
                <input type="date" id="d">
            </div>
            
            <button class="btn-search" onclick="search()">Show Categories</button>
            
            <div class="cat-row" id="cats" style="display:none">
                <div class="cat-btn" onclick="showChain('PVR')">PVR</div>
                <div class="cat-btn" onclick="showChain('Scope')">SCOPE</div>
                <div class="cat-btn" onclick="showChain('Lite')">LITE</div>
                <div class="cat-btn" onclick="showChain('EAP')">EAP</div>
                <div class="cat-btn" onclick="showChain('Independent')">INDIE</div>
            </div>
        </div>
    </div>

    <div id="results-overlay">
        <button onclick="document.getElementById('results-overlay').style.display='none'" style="background:none; border:1px solid white; color:white; padding:10px; margin-bottom:20px; cursor:pointer">Back</button>
        <div id="res-list"></div>
    </div>

    <script>
        const cityData = {{ city_data|tojson }};
        const chains = {{ chains|tojson }};

        function search() {
            const d = new Date(document.getElementById('d').value);
            const today = new Date();
            const diff = Math.ceil((d - today) / (1000 * 60 * 60 * 24));
            
            if (diff > 4 || diff < 0) {
                alert("Date not available. Select a date within 4 days.");
                return;
            }
            document.getElementById('cats').style.display = 'grid';
        }

        function showChain(name) {
            const list = chains[name];
            const selCity = document.getElementById('c').value;
            const selTrailer = document.getElementById('m').value;
            const res = document.getElementById('res-list');
            res.innerHTML = '';
            
            // Filter halls by both Chain and City
            const filtered = list.filter(h => cityData[selCity].includes(h));
            
            if(filtered.length === 0) {
                res.innerHTML = `<h2 style='text-align:center'>No ${name} Cinemas in ${selCity}</h2>`;
            } else {
                filtered.forEach(h => {
                    const mapUrl = 'https://www.google.com/maps/search/' + encodeURIComponent(h + ' Sri Lanka');
                    res.innerHTML += `
                        <div class="cinema-card">
                            <h3>${h}</h3>
                            <div class="btn-grp">
                                <a href="${selTrailer}" class="btn-s b-tra" target="_blank">Trailer</a>
                                <a href="${mapUrl}" class="btn-s b-loc" target="_blank">Location</a>
                                <a href="#" class="btn-s b-book">Book Now</a>
                            </div>
                        </div>`;
                });
            }
            document.getElementById('results-overlay').style.display = 'block';
        }
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(
        HTML_PAGE,
        movies=MOVIES,
        cities=sorted(CITY_DATA.keys()),
        city_data=CITY_DATA,
        chains=CHAINS
    )

if __name__ == '__main__':
    app.run(debug=True)