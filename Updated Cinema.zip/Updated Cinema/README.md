# 🎬 CineLanka – Sri Lanka Cinema Guide

A professional web app to find cinemas across Sri Lanka, browse by chain, and book tickets.

---

## 📁 Project Structure

```
cinelanka/
├── app.py                  ← Flask backend (Python)
├── requirements.txt        ← Python dependencies
├── templates/
│   └── index.html          ← Main HTML template
└── static/
    ├── css/
    │   └── style.css       ← All styling
    └── js/
        └── main.js         ← Frontend logic
```

---

## 🚀 How to Run in VS Code

### Step 1 – Open the project folder in VS Code
```
File → Open Folder → select the "cinelanka" folder
```

### Step 2 – Open the Terminal in VS Code
```
Terminal → New Terminal   (or press Ctrl + ` )
```

### Step 3 – Create a virtual environment (recommended)
```bash
python -m venv venv
```

Activate it:
- **Windows:**   `venv\Scripts\activate`
- **Mac/Linux:** `source venv/bin/activate`

### Step 4 – Install dependencies
```bash
pip install -r requirements.txt
```

### Step 5 – Run the app
```bash
python app.py
```

### Step 6 – Open in browser
```
http://localhost:5000
```

---

## 🌟 Features

| Feature | Details |
|---|---|
| 🔍 Search | Filter by city + date |
| 🎭 5 Cinema Chains | PVR, Scoop, Lite, EAP, Independent |
| 📍 GPS Directions | Google Maps link for every cinema |
| 🎟 Online Booking | BookMyShow / official links |
| 📱 Responsive | Works on mobile & desktop |
| 🌙 Dark Theme | Premium dark UI |

---

## 🏙️ Covered Cities
Colombo, Gampaha, Kalutara, Kandy, Matara, Galle, Hambantota,
Kurunegala, Puttalam, Anuradhapura, Trincomalee, Badulla, Rathnapura

---

## 🔧 API Endpoints

| Endpoint | Description |
|---|---|
| `GET /` | Main app page |
| `GET /api/cinemas/<category>` | Get cinemas by chain (pvr/scoop/lite/eap/independent) |
| `GET /api/cinemas/<category>?city=Colombo` | Filter by city too |
| `GET /api/cities/<city>` | Get all cinemas in a city |
| `GET /api/categories` | Get category metadata |
