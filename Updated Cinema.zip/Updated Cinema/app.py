from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# ─────────────────────────────────────────────
#  DATA
# ─────────────────────────────────────────────

CINEMAS = {
    "pvr": [
        {
            "name": "PVR Cinemas – One Galle Face Mall",
            "location": "One Galle Face Mall, Colombo 02",
            "city": "Colombo",
            "desc": "Sri Lanka's most premium 9-screen multiplex featuring PVR LUXE (luxury recliners), PVR P[XL] (large screen format), and PVR Playhouse (designed for children).",
            "map": "https://maps.google.com/?q=PVR+Cinema+One+Galle+Face+Mall+Colombo",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/pvr-cinema-one-galle-face-mall/POGF"
        }
    ],
    "scoop": [
        {
            "name": "Scope Cinemas – Colombo City Centre",
            "location": "Colombo City Centre Mall, Colombo 02",
            "city": "Colombo",
            "desc": "A 6-screen multiplex at CCC Mall featuring Gold Class (luxury seating) and 4K Dolby Atmos projection.",
            "map": "https://maps.google.com/?q=Scope+Cinemas+Colombo+City+Centre",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/scope-cinemas-colombo-city-center/CCCS"
        },
        {
            "name": "Scope Cinemas – Havelock City Mall",
            "location": "Havelock City Mall, Colombo 05",
            "city": "Colombo",
            "desc": "The flagship 6-screen multiplex — Sri Lanka's first IMAX with Laser and Dolby Atmos.",
            "map": "https://maps.google.com/?q=Scope+Cinemas+Havelock+City+Mall+Colombo",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/scope-cinemas-multiplex-havelock-city-mall/SCMH"
        },
        {
            "name": "Liberty by Scope – Colpetty",
            "location": "Liberty Plaza, Colombo 03",
            "city": "Colombo",
            "desc": "Historic location at Liberty Plaza. Screen 1 is the largest single screen in Sri Lanka with 387 seats.",
            "map": "https://maps.google.com/?q=Liberty+by+Scope+Cinemas+Liberty+Plaza+Colombo",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/liberty-by-scope-cinemas-colombo-screen-1/LCCS"
        },
        {
            "name": "Liberty by Scope – Kiribathgoda",
            "location": "Makola Road, Kiribathgoda, Gampaha",
            "city": "Gampaha",
            "desc": "A dual-screen cinema on Makola Road, serving the Gampaha district.",
            "map": "https://maps.google.com/?q=Liberty+Scope+Cinemas+Kiribathgoda",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/liberty-scope-cinemas-kiribathgoda/LSSK"
        }
    ],
    "lite": [
        {
            "name": "Sky Lite 3D",
            "location": "Central Bus Stand, New Tangalla Rd, Matara",
            "city": "Matara",
            "desc": "Upper Floor, Central Bus Stand, New Tangalla Road, Matara.",
            "map": "https://maps.google.com/?q=Sky+Lite+3D+Cinema+Matara",
            "ticket": "https://lk.bookmyshow.com/buytickets/sky-lite-3d-cinema-matara/cinema-snlk-SKKS-MT/20260301"
        },
        {
            "name": "MaxX Lite 3D",
            "location": "K-Zone Mall, Galle Road, Moratuwa",
            "city": "Colombo",
            "desc": "Modern 3D cinema located at K-Zone Mall, Galle Road, Moratuwa.",
            "map": "https://maps.google.com/?q=Maxx+Lite+3D+Cinema+Moratuwa",
            "ticket": "https://lk.bookmyshow.com/buytickets/maxx-lite-3d-cinema-moratuwa/cinema-snlk-MAXC-MT/20260301"
        },
        {
            "name": "Amity Lite 3D",
            "location": "Amity Building, High Level Road, Maharagama",
            "city": "Colombo",
            "desc": "Amity Building, High Level Road, Maharagama.",
            "map": "https://maps.google.com/?q=Amity+Lite+3D+Cinema+Maharagama",
            "ticket": "https://lk.bookmyshow.com/buytickets/amity-lite-3d-cinema-maharagama/cinema-snlk-AAMM-MT/20260301"
        },
        {
            "name": "Aqua Lite 3D",
            "location": "No. 16, St. Christopher Road, Negombo",
            "city": "Gampaha",
            "desc": "No. 16, St. Christopher Road, Negombo.",
            "map": "https://maps.google.com/?q=Aqua+Lite+3D+Cinema+Negombo",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/aqua-lite-3d-cinema-negombo/ALCN"
        },
        {
            "name": "VoxX Lite 3D",
            "location": "Colombo Road, Avissawella",
            "city": "Colombo",
            "desc": "Colombo Road, Avissawella.",
            "map": "https://maps.google.com/?q=VoxX+Lite+3D+Cinema+Avissawella",
            "ticket": "https://lk.bookmyshow.com/buytickets/voxx-lite-3d-cinema-avissawella/cinema-snlk-VOXX-MT/20260301"
        },
        {
            "name": "City Lite",
            "location": "143, Templers Road, Mt. Lavinia",
            "city": "Colombo",
            "desc": "143, Templers Road, Mt. Lavinia.",
            "map": "https://maps.google.com/?q=City+Lite+Cinema+Mt+Lavinia",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/city-lite-cinema-mt-lavinia/CLCL"
        },
        {
            "name": "Nikado by Lite",
            "location": "Kandy Road, Kadawatha",
            "city": "Colombo",
            "desc": "Kandy Road, Kadawatha.",
            "map": "https://maps.google.com/?q=Nikado+Lite+Cinema+Kadawatha",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/nikado-cinema-kadawatha/NNCC"
        },
        {
            "name": "Lite Cinema – Lekha",
            "location": "Station Road, Homagama",
            "city": "Colombo",
            "desc": "Station Road, Homagama.",
            "map": "https://maps.google.com/?q=Lite+Cinema+Homagama",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/lite-cinema-lekha-homagama/LLLM"
        },
        {
            "name": "Lite Cinema – Vijayanthi",
            "location": "New Kandy Road, Kaduwela",
            "city": "Colombo",
            "desc": "New Kandy Road, Opposite Municipal Council, Kaduwela.",
            "map": "https://maps.google.com/?q=Lite+Cinema+Kaduwela",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/vijayanthi-by-lite-cinemas-kaduwela/VLCK"
        },
        {
            "name": "Misty Lite 3D",
            "location": "Super Commercial Complex, Nawalapitiya",
            "city": "Kandy",
            "desc": "3rd Floor, Super Commercial Complex, Nawalapitiya.",
            "map": "https://maps.google.com/?q=Misty+Lite+3D+Cinema+Nawalapitiya",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/misty-lite-3d-cinema-nawalapitiya/MLCN"
        },
        {
            "name": "Neela by Lite",
            "location": "Toppuwa-Madampe Road, Dankotuwa",
            "city": "Puttalam",
            "desc": "Toppuwa-Madampe Road, Dankotuwa.",
            "map": "https://maps.google.com/?q=Neela+Lite+Cinema+Dankotuwa",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/neela-by-lite-cinema-dankotuwa/NLCD"
        },
        {
            "name": "Sarasavi by Lite",
            "location": "Dampelessa Road, Alawwa",
            "city": "Kurunegala",
            "desc": "Dampelessa Road, Alawwa.",
            "map": "https://maps.google.com/?q=Sarasavi+Cinema+Alawwa",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/sarasavi-cinema-alawwa/SCCA"
        },
        {
            "name": "Priska Lite 3D",
            "location": "Lake Road, Kalutara",
            "city": "Kalutara",
            "desc": "Lake Road, Kalutara.",
            "map": "https://maps.google.com/?q=Priska+Lite+3D+Cinema+Kalutara",
            "ticket": "https://lk.bookmyshow.com/buytickets/priska-lite-3d-cinema-kalutara/cinema-snlk-PLCK-MT/20260301"
        }
    ],
    "eap": [
        {
            "name": "Savoy 3D – Dolby ATMOS",
            "location": "Wellawatte, Colombo",
            "city": "Colombo",
            "desc": "Flagship EAP theater with Dolby Atmos surround sound.",
            "map": "https://maps.google.com/?q=Savoy+3D+Wellawatte+Colombo",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/savoy-3d-dolby-atmos-wellawatta/SCWT"
        },
        {
            "name": "Savoy 2",
            "location": "Wellawatte, Colombo",
            "city": "Colombo",
            "desc": "Located within the same Savoy building, Wellawatte.",
            "map": "https://maps.google.com/?q=Savoy+Cinema+Wellawatte+Colombo",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/savoy-3d-dolby-atmos-wellawatta/SCWT"
        },
        {
            "name": "Savoy Premiere – Roxy",
            "location": "Wellawatte, Colombo",
            "city": "Colombo",
            "desc": "Historically known as Roxy Cinema, now a premium Savoy screen.",
            "map": "https://maps.google.com/?q=Savoy+Premiere+Roxy+Wellawatte+Colombo",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/savoy-premiere-roxy-cinema-wellawatte/SCPW"
        },
        {
            "name": "Savoy Premier",
            "location": "Jana Jaya City Complex, Rajagiriya",
            "city": "Colombo",
            "desc": "Located at the Jana Jaya City complex, Rajagiriya.",
            "map": "https://maps.google.com/?q=Savoy+Premier+Rajagiriya",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/savoy-premier-rajagiriya/SPRG"
        },
        {
            "name": "Savoy Metro",
            "location": "Maharagama Commercial Complex, Maharagama",
            "city": "Colombo",
            "desc": "Modern theater at the Maharagama Commercial Complex.",
            "map": "https://maps.google.com/?q=Savoy+Metro+Maharagama",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/savoy-metro-maharagama/SCMA"
        },
        {
            "name": "Savoy Metro – Gampaha",
            "location": "Ward City Complex, 7th Floor, Gampaha",
            "city": "Gampaha",
            "desc": "Situated on the 7th floor of the Ward City complex, Gampaha.",
            "map": "https://maps.google.com/?q=Savoy+Metro+Gampaha",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/savoy-metro-gampaha/SMGS"
        },
        {
            "name": "S.K Cinema",
            "location": "Beach Road, Matara",
            "city": "Matara",
            "desc": "Located on Beach Road, Matara.",
            "map": "https://maps.google.com/?q=SK+Cinema+Matara",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/sk-cinema-matara/SKCM"
        },
        {
            "name": "Sinexpo 3D",
            "location": "Kurunegala",
            "city": "Kurunegala",
            "desc": "One of the top-end cinemas in the Kurunegala district.",
            "map": "https://maps.google.com/?q=Sinexpo+3D+Cinema+Kurunegala",
            "ticket": "https://lk.bookmyshow.com/buytickets/sinexpo-3d-kurunegala/cinema-snlk-SNKG-MT/20260301"
        },
        {
            "name": "Willmax",
            "location": "Anuradhapura",
            "city": "Anuradhapura",
            "desc": "Primary EAP cinema for the North Central province.",
            "map": "https://maps.google.com/?q=Willmax+Cinema+Anuradhapura",
            "ticket": "https://lk.bookmyshow.com/buytickets/willmax-anuradhapura/cinema-snlk-WCAP-MT/20260301"
        },
        {
            "name": "Cinemax 3D",
            "location": "Reality Plaza, Colombo Road, Ja-Ela",
            "city": "Gampaha",
            "desc": "Located within Reality Plaza on Colombo Road, Ja-Ela.",
            "map": "https://maps.google.com/?q=Cinemax+3D+Jaela",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/cinemax-3d-jaela/CCJL"
        },
        {
            "name": "Concord",
            "location": "Galle Road, Dehiwala",
            "city": "Colombo",
            "desc": "Situated on Galle Road, Dehiwala.",
            "map": "https://maps.google.com/?q=Concord+Cinema+Dehiwala",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/concord-dehiwala/CCDL"
        },
        {
            "name": "Regal",
            "location": "Ambalangoda, Galle",
            "city": "Galle",
            "desc": "Managed under the EAP circuit in the Southern province.",
            "map": "https://maps.google.com/?q=Regal+Cinema+Ambalangoda",
            "ticket": "https://lk.bookmyshow.com/buytickets/regal-ambalangoda/cinema-snlk-RCAG-MT/20260301"
        },
        {
            "name": "Jothi",
            "location": "Ratnapura",
            "city": "Rathnapura",
            "desc": "The main EAP theater in the Ratnapura area.",
            "map": "https://maps.google.com/?q=Jothi+Cinema+Ratnapura",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/jothi-rathnapura/JPRP"
        },
        {
            "name": "Samantha 2D",
            "location": "Baseline Road, Dematagoda",
            "city": "Colombo",
            "desc": "Historically significant cinema on Baseline Road, Dematagoda.",
            "map": "https://maps.google.com/?q=Samantha+Cinema+Dematagoda",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/samantha-cinema-dematagoda/SCDG"
        }
    ],
    "independent": [
        {
            "name": "Ram Cinema",
            "location": "Wattala, Gampaha",
            "city": "Gampaha",
            "desc": "High-end independent cinema serving the north of Colombo.",
            "map": "https://maps.google.com/?q=Ram+Cinema+Wattala",
            "ticket": "https://lk.bookmyshow.com/buytickets/ram-cinemas-wattala/cinema-snlk-RCCW-MT/20260301"
        },
        {
            "name": "Ruhunu Cinema",
            "location": "Tangalle, Hambantota",
            "city": "Hambantota",
            "desc": "Classic single-screen independent cinema in Tangalle.",
            "map": "https://maps.google.com/?q=Ruhunu+Cinema+Tangalle",
            "ticket": "https://cinematreasures.org/theaters/44360"
        },
        {
            "name": "CK Cinema",
            "location": "Kirindiwela, Gampaha",
            "city": "Gampaha",
            "desc": "Modern 3D independent cinema in Kirindiwela.",
            "map": "https://maps.google.com/?q=CK+Cinema+Kirindiwela",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/ck-cinema-kirindiwela/CKCK"
        },
        {
            "name": "Imperial 3D",
            "location": "Town Center, Kurunegala",
            "city": "Kurunegala",
            "desc": "Large independent theater in the town center of Kurunegala.",
            "map": "https://maps.google.com/?q=Imperial+3D+Cinema+Kurunegala",
            "ticket": "https://lk.bookmyshow.com/buytickets/imperial-3d-cinema-kurunegala/cinema-snlk-IMDK-MT/20260301"
        },
        {
            "name": "Sarasavi Cinema",
            "location": "Alawwa, Kurunegala",
            "city": "Kurunegala",
            "desc": "Regional single-screen cinema, Alawwa.",
            "map": "https://maps.google.com/?q=Sarasavi+Cinema+Alawwa",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/sarasavi-cinema-alawwa/SCCA"
        },
        {
            "name": "Ruoo Cinema",
            "location": "Katunayake, Gampaha",
            "city": "Gampaha",
            "desc": "Located near the airport; modern 3D cinema.",
            "map": "https://maps.google.com/?q=Ruoo+Cinema+Katunayake",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/ruoo-cinema-katunayake/RCNM"
        },
        {
            "name": "New Janaki",
            "location": "Mathugama, Kalutara",
            "city": "Kalutara",
            "desc": "Well-maintained regional theater in Mathugama.",
            "map": "https://maps.google.com/?q=New+Janaki+Cinema+Mathugama",
            "ticket": "https://lk.bookmyshow.com/sri-lanka/cinemas/new-janaki-cinema-mathugama/NJCM"
        },
        {
            "name": "SAS Cineplex",
            "location": "Trincomalee",
            "city": "Trincomalee",
            "desc": "The primary modern cinema for the Eastern province.",
            "map": "https://maps.google.com/?q=SAS+Cineplex+Trincomalee",
            "ticket": "https://lk.bookmyshow.com/buytickets/sas-cineplex-trincomale/cinema-snlk-SASC-MT/20260301"
        },
        {
            "name": "Rex Theater",
            "location": "Badulla",
            "city": "Badulla",
            "desc": "Prominent Uva province theater.",
            "map": "https://maps.google.com/?q=Rex+Theater+Badulla",
            "ticket": "https://lk.bookmyshow.com/buytickets/rex-theater-badulla/cinema-snlk-RXXE-MT/20260301"
        },
        {
            "name": "Nikado Cinema",
            "location": "Kadawatha",
            "city": "Colombo",
            "desc": "Often partners with Lite Cinemas for booking.",
            "map": "https://maps.google.com/?q=Nikado+Cinema+Kadawatha",
            "ticket": "https://lk.bookmyshow.com/buytickets/nikado-cinema-kadawatha/cinema-snlk-NNCC-MT/20260301"
        },
        {
            "name": "Shamrock Cinema",
            "location": "Wennappuwa, Gampaha",
            "city": "Gampaha",
            "desc": "Important coastal independent theater.",
            "map": "https://maps.google.com/?q=Shamrock+Cinema+Wennappuwa",
            "ticket": "https://lk.bookmyshow.com/buytickets/shamrock-cinema-wennappuwa/cinema-snlk-SSCO-MT/20260301"
        },
        {
            "name": "Vijaya Cinema",
            "location": "Minuwangoda, Gampaha",
            "city": "Gampaha",
            "desc": "Traditional town theater in Minuwangoda.",
            "map": "https://maps.google.com/?q=Vijaya+Cinema+Minuwangoda",
            "ticket": "https://lk.bookmyshow.com/buytickets/vijaya-cinema-minuwangoda/cinema-snlk-VCCM-MT/20260301"
        },
        {
            "name": "KCC Multiplex",
            "location": "Kandy City Centre, Kandy",
            "city": "Kandy",
            "desc": "Modern multiplex located in the Kandy City Centre mall.",
            "map": "https://maps.google.com/?q=KCC+Multiplex+Kandy+City+Centre",
            "ticket": "https://kccmultiplex.lk/buy-tickets/"
        },
        {
            "name": "JP Complex",
            "location": "Kandy",
            "city": "Kandy",
            "desc": "Multi-screen cinema complex in the heart of Kandy.",
            "map": "https://maps.google.com/?q=JP+Cineplex+Kandy",
            "ticket": "https://www.jpcineplex.com/"
        },
        {
            "name": "Ananda Cinema",
            "location": "Gampola, Kandy",
            "city": "Kandy",
            "desc": "Classic regional cinema serving the Gampola area.",
            "map": "https://maps.google.com/?q=Ananda+Cinema+Gampola",
            "ticket": "https://dialus.lk/listing/Kandy/Gampola/ananda-cinema/4102"
        }
    ]
}

CITIES = [
    "Colombo", "Gampaha", "Kalutara", "Kandy",
    "Matara", "Galle", "Hambantota", "Kurunegala",
    "Puttalam", "Anuradhapura", "Trincomalee", "Badulla", "Rathnapura"
]

CATEGORY_META = {
    "pvr":          {"label": "PVR Cinemas",       "icon": "🎭", "color": "#7c3aed", "count": 1},
    "scoop":        {"label": "Scoop Cinemas",      "icon": "🍿", "color": "#0ea5e9", "count": 4},
    "lite":         {"label": "Lite Cinemas",       "icon": "💡", "color": "#22c55e", "count": 13},
    "eap":          {"label": "EAP Cinemas",        "icon": "🎥", "color": "#e83a3a", "count": 14},
    "independent":  {"label": "Independent",        "icon": "🏟️", "color": "#f97316", "count": 15},
}

# ─────────────────────────────────────────────
#  ROUTES
# ─────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html", cities=CITIES, category_meta=CATEGORY_META)

@app.route("/api/cinemas/<category>")
def get_cinemas(category):
    city_filter = request.args.get("city", "").strip()
    data = CINEMAS.get(category, [])
    if city_filter:
        data = [c for c in data if c["city"].lower() == city_filter.lower()]
    return jsonify(data)

@app.route("/api/cities/<city>")
def get_city_cinemas(city):
    results = []
    for cat, items in CINEMAS.items():
        for cinema in items:
            if cinema["city"].lower() == city.lower():
                results.append({**cinema, "category": cat})
    return jsonify(results)

@app.route("/api/categories")
def get_categories():
    return jsonify(CATEGORY_META)

# ─────────────────────────────────────────────
#  RUN
# ─────────────────────────────────────────────

if __name__ == "__main__":
    app.run(debug=True, port=5000)
