from flask import Flask, render_template_string

app = Flask(__name__)

# --- Updated Movie Data with 8 Films and specific Trailers ---
MOVIES = [
    {"id": 1, "title": "Father", "img": "father", "trailer": "https://www.youtube.com/embed/IhgcUArO3Uo?autoplay=1"},
    {"id": 2, "title": "Dharmayuddaya 02", "img": "dharmayuddaya", "trailer": "https://www.youtube.com/embed/HtQP3QItZGY?autoplay=1"},
    {"id": 3, "title": "Malaki Duwe Numba", "img": "malaki", "trailer": "https://www.youtube.com/embed/WU79Q8o5br8?autoplay=1"},
    {"id": 4, "title": "Karuppu", "img": "karuppu", "trailer": "https://www.youtube.com/embed/Llss1aRo8tw?autoplay=1"},
    {"id": 5, "title": "The Bride", "img": "bride", "trailer": "https://www.youtube.com/embed/IhgcUArO3Uo?autoplay=1"},
    {"id": 6, "title": "Zootopia 2", "img": "zootopia", "trailer": "https://www.youtube.com/embed/BjkIOU5PhyQ?autoplay=1"},
    {"id": 7, "title": "Avatar: Fire and Ash", "img": "avatar", "trailer": "https://www.youtube.com/embed/nb_fFj_0rq8?autoplay=1"},
    {"id": 8, "title": "Upcoming Feature", "img": "father", "trailer": ""}, # Placeholder 8th film
]

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Movie Booking Platform</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background: #121212; color: white; font-family: sans-serif; display: flex; flex-direction: column; align-items: center; }
        .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; padding: 20px; }
        .card { background: #1e1e1e; padding: 10px; border-radius: 10px; cursor: pointer; transition: 0.3s; width: 200px; text-align: center; }
        .card:hover { transform: scale(1.05); background: #333; }
        .card img { width: 100%; border-radius: 8px; }
        
        /* Modal Style */
        #trailerModal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); justify-content: center; align-items: center; z-index: 1000; }
        .modal-content { position: relative; width: 80%; max-width: 800px; }
        .close { position: absolute; top: -40px; right: 0; font-size: 30px; cursor: pointer; color: white; }
        
        /* Calendar Section */
        .controls { margin-top: 30px; text-align: center; background: #222; padding: 20px; border-radius: 15px; }
        .cal-btn { background: #e50914; color: white; border: none; padding: 10px 20px; border-radius: 5px; cursor: pointer; font-size: 16px; }
        #datePicker { margin-top: 10px; display: none; padding: 5px; }
        #statusMessage { margin-top: 15px; font-weight: bold; color: #ffcc00; }
    </style>
</head>
<body>

    <h1>Now Showing (8 Films)</h1>
    
    <div class="grid">
        {% for movie in movies %}
        <div class="card" onclick="playTrailer('{{ movie.trailer }}', '{{ movie.title }}')">
            <img src="https://via.placeholder.com/200x300?text={{ movie.title }}" alt="{{ movie.title }}">
            <h3>{{ movie.title }}</h3>
        </div>
        {% endfor %}
    </div>

    <div class="controls">
        <button class="cal-btn" onclick="toggleCalendar()">
            <i class="fa-solid fa-calendar-days"></i> Select Show Date
        </button>
        <br>
        <input type="date" id="datePicker" onchange="checkAvailability()">
        <div id="statusMessage"></div>
    </div>

    <div id="trailerModal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <iframe id="trailerFrame" width="100%" height="450" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
        </div>
    </div>

    <script>
        function playTrailer(url, title) {
            if(!url) { alert("Trailer not available yet!"); return; }
            document.getElementById('trailerFrame').src = url;
            document.getElementById('trailerModal').style.display = 'flex';
            // Also automatically open calendar to show intent
            document.getElementById('datePicker').style.display = 'inline-block';
        }

        function closeModal() {
            document.getElementById('trailerModal').style.display = 'none';
            document.getElementById('trailerFrame').src = "";
        }

        function toggleCalendar() {
            const picker = document.getElementById('datePicker');
            picker.style.display = picker.style.display === 'none' ? 'inline-block' : 'none';
        }

        function checkAvailability() {
            const selectedDate = new Date(document.getElementById('datePicker').value);
            const today = new Date();
            today.setHours(0,0,0,0);
            
            // Calculate difference in days
            const diffTime = selectedDate - today;
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

            const msg = document.getElementById('statusMessage');
            
            if (diffDays < 0) {
                msg.innerText = "Error: Cannot select a past date.";
                msg.style.color = "red";
            } else if (diffDays > 4) {
                msg.innerText = "Result: This date is not available. Shows are only open for the next 4 days.";
                msg.style.color = "red";
            } else {
                msg.innerText = "Success! Book My Show platform selected for " + selectedDate.toDateString();
                msg.style.color = "#00ff00";
            }
        }
    </script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE, movies=MOVIES)

if __name__ == '__main__':
    app.run(debug=True)